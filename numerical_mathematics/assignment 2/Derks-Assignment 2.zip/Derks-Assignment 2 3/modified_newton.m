function [zero,order,xvalues]=modified_newton(fun,dfun,x0,tol,...
                                 nmax,varargin)
%MODIFIED NEWTON Finds function zeros.
% Peter-Jan Derks 11065540
% [ZERO,RES,NITER] = NEWTON(FUN,DFUN,X0,TOL,...NMAX) tries to find the
% root of the continuous and differentiable
% function FUN nearest to X0 using the modified Newton method.
% FUN and its derivative DFUN accept real scalar input
% x and return a real scalar value. If the search
% fails an error message is displayed. FUN and DFUN
% can be either inline functions or anonymous
% functions or they can be defined by external m-files.
% ZERO=NEWTON(FUN,DFUN,X0,TOL,NMAX,P1,P2,...) passes
% parameters P1,P2,... to functions: FUN(X,P1,P2,...)
% and DFUN(X,P1,P2,...).
% [ZERO,RES,NITER]=NEWTON(FUN,...) returns the value of
% the residual in ZERO and the iteration number at
% which ZERO was computed.

if ~exist('nmax') %max number of iterations is an optional input
    nmax = 10;
end

if ~exist('tol') %error tolerance is an optional input
    tol = 0.005;
end

p = zeros(1,nmax);
x = x0;
p(1,1) = x0;
fx = feval(fun,x,varargin{:});
dfx = feval(dfun,x,varargin{:});
niter = 1; 

for i = 2:3 %for the first three points m = 1 is used
   diff = - fx/dfx;
   x = x + diff;           
   diff = abs(diff);
   fx = feval(fun,x,varargin{:});
   dfx = feval(dfun,x,varargin{:});
   p(1,i) = x;
end

m = ((p(1,1) - p(1,2))/(p(1,3) - 2*p(1,2) + p(1,1)));
i = 1; %the first three points are calculated again in the while loop
x = x0;

while  niter < nmax && diff >= tol  
   niter = niter + 1;
   diff = - fx/dfx;
   x = x + m*diff;          
   diff = abs(diff); %for the condition of the while loop 
   fx = feval(fun,x,varargin{:});
   dfx = feval(dfun,x,varargin{:});
   p(1,i) = x;
   i = i + 1;
   y(i) = feval(fun, x);
end

plot(p, y,'-')
title('Convergence to zero')
xlabel('x') 
ylabel('f(x)') 

if (niter==nmax && diff > tol) 
    fprintf(['modified Newton stopped without converging to',...
    'the desired tolerance because the maximum\n ',...
    'number of iterations was reached\n']);
end

%returns the three outputs:
order = m 
zero = x
xvalues = p

end

