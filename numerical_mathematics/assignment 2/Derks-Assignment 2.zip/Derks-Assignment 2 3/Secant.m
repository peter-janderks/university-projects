function [zero, xvalues] = Secant(fun,x1,x2,tol,nmax)
%NEWTON Finds function zeros.
% Peter-Jan Derks 11065540
% [ZERO,X]=NEWTON(FUN,X1,X2,TOL,NMAX) tries to find the
% root of the continuous FUN using the Secant method.
% FUN accepts real scalar input X and returns a real scalar value.
% If the search fails an error message is displayed. FUN can be 
% either inline functions or anonymousfunctions or they can 
% be defined by external m-files. [ZERO,XVALUES]=SECANT(FUN,...)
% returns the value of the residual in ZERO, a vector of approximate
% values obtained in the iterations and plots a graph of showing the
% convergence to zero.

clf %clears the previous figure

if ~exist('nmax') %max number of iterations is an optional input
    nmax = 10;
end

if ~exist('tol') %tolerated error of iterations is an optional input
    tol = 0.05;
end

x(1) = x1;
x(2) = x2;
i = 2;
diff = tol + 1; 
niter = 0;

while diff >= tol && niter < nmax 
   niter = niter + 1;  
   i = i + 1; 
   diff = - (fun(x(i-1)))*((x(i-1) - x(i-2))/(fun(x(i-1)) - fun(x(i-2))));    
   x(i) = x(i-1) + diff;
   y(i) = feval(fun, x(i)); %needed for the plot
   diff = abs(diff); %for the condition of the while loop 
end

plot(x, y,'-')

title('Convergence to zero')
xlabel('x') 
ylabel('f(x)') 

if (niter==nmax && diff > tol)
    fprintf(['Newton stopped without converging to the desired'... 
        ' tolerance because max number of iterations was reached\n']);
end

zero = x(i);
xvalues = x

end

