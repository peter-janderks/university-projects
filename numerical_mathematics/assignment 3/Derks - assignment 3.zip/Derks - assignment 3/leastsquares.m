function [lambda,constants,fresidue]=leastsquares(data,initialguesses)
% leastsquares fits a linear combination of exponential functions to data
% Peter-Jan Derks
% [LAMBDA,CONSTANTS,RESIDUAL]=leastsquares(DATA,INITIALGUESSES) looks 
% for the exponents and constants such that "optimalfunction" is the best 
% fit of the data in the sense of least squares. DATA accepts a matrix 
% consisting of x and y values of points as an input and INITIALGUESSES
% accepts a vector that guesses the optimal exponents. Leastsquares
% returns two vectors one with the calculated optimal exponenents LAMBDA 
% and one with the c alculated optimal constants CONSTANTS. Additionaly it
% returns the residual and a picture of the data and the fit of f.

lambda = initialguesses;

xvalues = data(:,1);
xmax = data(end,1);
yvalues = data(:,2);

% calculates the optimal constants
A = exp(xvalues * lambda);
constants= pinv(A) * yvalues;

% calculates the optimal lambdas
exponentialfunction =  exp(xvalues * lambda) * constants;
fresidue = @(exponentialfunction) norm(exponentialfunction - yvalues);
optimallambda = fminsearch(fresidue,lambda);

% calculates the y-values the function, which is a linear combination of
% exponential function, gives for the x-values of the
A = exp(xvalues * optimallambda);
constants = pinv(A) * yvalues
optimalfunction = A * constants;

plot (xvalues,yvalues,'.',xvalues,optimalfunction,'-')
title('Exponential function fit to data')
xlabel('x') 
ylabel('y')

residue = norm((exp(xvalues * optimallambda) * constants) - yvalues)

end



