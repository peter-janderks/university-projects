function [] = Center()
% Determines the center of mass of the users hand.
% Peter-Jan Derks
% []=Center() determines the center of mass of a domain enclosed by an 
% interpolated curve. This function has no input or output variables. It 
% opens a figure with a big rectangle on the screen. In the command window
% the function asks the user to put his hand on the rectangle and outline 
% the circumference of his hand with 40 mouse clicks. Next, the function 
% interpolates these points with splines to obtain a nice (hand) shape and
% calculates (approximately) the center of mass. Finally, the function 
% produces a picture of the input points, the interpolated curve, and the 
% area inside the curve, with a clear mark at the center of mass.


 
fprintf(['Trace your hand on the screen using 40 points, the function ',... 
    'will then calculate and show you where the center of mass of your ',...
    'hand is\n']);

figh = figure('Name','for instructions, see the command window',...
               'NumberTitle','off');
pos = get(figh,'position');
set(figh,'position',[pos(1:2)/4 pos(3:4)*2]);

nmax=3;

% the following code (till the end of the while loop) prevents the user from
% clicking on the same point twice in a row. (this makes the function
% very slow). it can be replaced by: [x,y] = ginput(nmax)
[x, y] = ginput(1);
n = 2;
while n <= nmax
[x, y] = ginput(n);
diffx = x(n) - x(n-1);
diffy = y(n) - y(n-1);
if diffx < 0.005 && diffy < 0.005
    fprintf('Do not click on the same point twice!\n');
else
    n = n + 1;
end 
end

Values = [x y];
points = nmax + 1;
x = zeros(points,1);
x = Values(:,1);
x(nmax+1) = Values(1,1);

y = zeros(points,1);
y = Values(:,2);
y(nmax+1) = Values(1,2);


t = zeros(1,points);

for i = 1:nmax
t(1,i+1) = t(1,i) + ((x(i+1) - x(i))^2 + (y(i+1) - y(i))^2)^0.5;
end

tmax = t(i+1);
T = linspace(0,tmax,500);
xx = spline(t,x,T);
yy = spline(t,y,T);
plot(xx,yy)

xdy = trapz(xx);
ydx = trapz(yy);
area = 0.5 * (xdy - ydx)
centerx = mean(xx)/area;
centery = mean(yy)/area;

plot(x,y,'o',xx, yy,'-',centerx,centery, 'd')

end

