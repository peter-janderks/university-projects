function [digits] = phonenumber(signal, samplingrate)
% PHONENUMBER finds the phonenumber of a sound signal
% Peter-Jan Derks 11065540
% [DIGITS] = PHONENUMBER(SIGNAL, SAMPLINGRATE) finds the phone number who's
% has been recorded. SIGNAL should be a one of the soundsignals from
% the files 'signal.mat' or 'phonenumbers.mat'. SAMPLINGRATE should be 
% 8192 if the 'signal,mat' file is called and 4096 if the
% 'phonenumbers.mat' file is called. The function returns the phone number
% in a row vector.

numbers = [];
i = 1;
signalonenumber = 300;

% finds the sections of the signal that represent a singel number being
% pressed
while i < length(signal)
    
    if abs(signal(i)) > 0.6
        onenumber = signal(i:i+signalonenumber);
        i = i + 2500;
        
        % numbers becomes a matrix with each column representing the signal
        % of one number being pressed
        numbers = [numbers onenumber];
    else
        i = i + 1;
    end    
end

[~,lengthphonenumber] = size(numbers);
frequencies = [];

L=300;
horizontal = [1209 1336 1447];
vertical = [697 770 852 941];
keys = [1 2 3;  4 5 6; 7 8 9; 11 0 12];
phonenumber = [];

% for loop such that each digit gets found one by one
for digit = 1:lengthphonenumber
    
    %finds the corresponding frequency to one point of the signal
    Y = fft(numbers(:,digit));
    P2 = abs(Y/L);
    P1 = P2(1:((L/2)+1));
    f = samplingrate * (0:(L/2))/ L;
    
    % splits the frequencies vector P1 into two parts, FIRSTHALF lower 
    % than 1100 and SECONDHALF higher than 1100
    p = round((1100/samplingrate) * L) + 1;
    firsthalf = P1(1:p);
    secondhalf = P1(p:end);
    
    [~, maxind1] = max(abs(firsthalf));
    [~, maxind2] = max(abs(secondhalf));
    
    maxfrequency1 = f(maxind1);
    maxfrequency2 = f(maxind2 + p);
    
    % finds which frequencies of phonenumbers are closest to the calculated
    % frequencies
    [~, fhind] = min(abs(maxfrequency2 - horizontal));
    [~, fvind] = min(abs(maxfrequency1 - vertical));
    p = keys(fvind,fhind);
    phonenumber = [phonenumber p];
end

digits = phonenumber;
end
