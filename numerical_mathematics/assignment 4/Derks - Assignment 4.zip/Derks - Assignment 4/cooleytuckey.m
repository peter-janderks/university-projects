function [Fouriertransform] = cooleytuckey(inputvector,type)
% COOLEYTUCKEY calculates the discrete or inverse Fourier transform
% Peter-Jan Derks 11065540
% [FOURIERCOEFFICIENTS] = COOLEYTUCKEY(INPUTVECTOR,TYPE) computes 
% the fft or ifft of the inputvector. INPUTVECTOR should be a row vector with 
% length of some power of 2. TYPE should be either '1' or '2', if the 
% users inputs 1, the discrete Fourier transform will be calculated, if 
% the user selects 2 the inverse Fourier transform will be calculated. 
% If the user does not enter 1 or 2 as the type an error message is 
% displayed. The function returns the fouriercoefficients in a column 
% vector.

N = length(inputvector);

% base case
if N == 1
    Fouriertransform = inputvector;
    return
    
% assigns values of variables for discrete Fourier transform
elseif type == 1
    imaginary = 1i;
    p = 1;

% assigns values of variables for inverse Fourier transform
elseif type == 2
    imaginary = -1i;
    p = 2;
    
else
    fprintf(['the input should be a vector of length 2^n and 1 for fft'...
        'and 2 for ifft\n']);
end

omega = exp(-2 * pi * imaginary/N) .^ (0:N/2-1).';

% recursive step, splitting the inputvector into its even and odd
% components
even = cooleytuckey(inputvector(1:2:N),type);
odd = omega .* cooleytuckey(inputvector(2:2:N),type);

% even and odd are not calculated in this line so that the programm doesn't
% calculate them twice
Fouriertransform = [even + odd; even - odd]/p;
end
