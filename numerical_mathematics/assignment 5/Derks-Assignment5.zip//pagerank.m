function [pagerankings] = pagerank(sp,urls,numberofsites)
% PAGERANK Sorts webpages according to their pagerank
%   Peter-Jan Derks
%
%   PAGERANKINGS=PAGERANK(G,URLS,NUMBEROFSITES) 
%   Calculates the pagerank of a set of webpages using a Sparse power 
%   method. The input G should be a sparse connection matrix. 
%   URLS is an optional input that should be either a row or column 
%   vector of urls of webpages connected to the matrix G. NUMBEROFSITES is
%   an optional input that decides the amount of webpages with highest
%   pageranking the user wants to see. If no input for NUMBEROFSITES is
%   given by the user the 10 webpages with highest pageranking are shown.
%   The output PAGERANKINGS is a sorted vector of pagerankings if no urls
%   are given and a table of sorted urls with their corresponding pagerank
%   if urls are given. Additionally the function produces a bar plot of the
%   pageranks. 

if ~exist('numberofsites')
    numberofsites = 10;
end
i = 1
n = length(sp);
p = 0.85;
delta = (1-p)/n;
% calcualtes sum of outgoing links for each url
c = sum(sp,1);

% all nonzero c's
k = find(c~=0);

% diagonal sparse matrix
D = sparse(k,k,1./c(k),n,n);

e = ones(n,1);

%one of the components of the transition matrix
z = ((1-p)*(c~=0) + (c==0))/n;

% calculation done outside while loop to improve speed
G = p*sp*D;

% initial x values for first iteration
pagerank = e/n;

% size of oldx preallocated to improve speed
oldx = zeros(n,1);

% power method, loop stops iterating when close to converged value
while norm(pagerank - oldx) > .0000001
oldx = pagerank;
pagerank = G*pagerank + e*(z*pagerank);
end

%formats the output
if ~exist('urls')
   pagerankings = sort(pagerank,'descend');
   pagerankings = pagerankings(1:numberofsites);
  
else
    if isrow(urls) == 1
        urls = urls';
    end
    
    %creates, sorts and selects top row of table with highest pageranking
    T = table(pagerank,urls);
    pagerankings = sortrows(T,-1);
    pagerankings = pagerankings(1:numberofsites,:);
end

% Bar graph
bar(pagerank)
title('Page Rank')
end