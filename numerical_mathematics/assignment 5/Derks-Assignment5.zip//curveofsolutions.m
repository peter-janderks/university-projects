function [zeros] = curveofsolutions(func,derivatives,startingpoint,...,
    stepsize,maxsteps,minstepsize,maxstepsize)
% CURVEOFSOLUTIONS continues the solution of an equation f(x)=0 
%   Peter-Jan Derks
%
%   [ZEROS]=CURVEOFSOLUTIONS(FUNC,DERIVATIVES,STARTINGPOINT,...,STEPSIZE,
%   MAXSTEPS, MINSTEPSIZE,MAXSTEPSIZE) 
%   calculates the set of solutions of FUNC: a system of n?1 (non-linear) 
%   equations with n unknowns. FUNC, STARTINGPOINT and MAXSTEPS are 
%   necessarry inputs and DERIVATIVES,STEPSIZE, MINSTEPSIZE and MAXSTEPSIZE
%   are optional inputs. FUNC should be a column vector of a system of 
%   equations. STARTINGPOINT should be a column vector of coordinates and 
%   STEPSIZE and MAXSTEPS should be scalar values representing size of the 
%   first step and the maximum number of steps the function should take. 
%   DERIVATIVES should be a column vector,if an empty matrix is given the 
%   function calculates the derivative itself. MINSTEPSIZE and 
%   MAXSTEPSIZE should be scalar values, if not provided by the user the
%   the function uses values 0.01 and 2.
%

if ~exist('minstepsize')
  minstepsize= 0;
end
if ~exist('maxstepsize')
  maxstepsize= inf;
end

xnew = startingpoint;

%calculates derivative if not given
if isempty(derivatives) ==  1
   l = @(t,x) func(x);
   derivatives = @(xnew) numjac(l,0,xnew,l(0,xnew),eps);
end

%finds first point on the curve
v = [];
v(:,1) = null(derivatives(xnew));
f = @(x) [func(x);v(:,1)'*(x-xnew)];
df = @(x) [derivatives(x); v(:,1)'];
xold = multinewton(f,df,xnew);

for i = 2:maxsteps

    %find direction in which the curve extends:
    v(:,i) = null(derivatives(xold));
    
    %changes direction if the angle between v's is bigger than 90 degrees
    if v(:,i)'*v(:,i-1) < 0
        stepsize = -stepsize;
    end

    xnew = xold + stepsize * v(:,i);
    
    %finds the next point by adding a function to the system of equations
    %of the function and its derivative and afterwards computing 
    %multinewton 
    f = @(x) [func(x); v(:,i)' * (x-xnew)];
    df = @(x)[derivatives(x); v(:,i)'];
    xold = multinewton(f,df,xnew);
    
    %decreases or increases stepsize depending on difference between point
    %on v and curve
    dif = abs(xnew - xold);
    if isempty(dif>0.01) && abs(stepsize) >= minstepsize
        stepsize = stepsize - 0.001;
    elseif abs(stepsize) < maxstepsize
        stepsize = stepsize + 0.001;
    end
    
    zeros(:,i-1) = xold;
    
end

plot(zeros(1,:),zeros(2,:))
end