function [g]=sine(x,terms)
% calculates the sine of a number using the Taylor series around 0 
% Peter-Jan Derks

k = zeros(length(x),terms); 
%will become a matrix with rows of the vector:[x -x x -x...]
m = zeros(length(x),terms); 
%will become a matrix with rows of the vector:[1 3 5 7...]
factorialmatrix = zeros(length(x),terms);
%will become a matrix with rows of vector:[1! 3! 5! 7!...]

z = zeros(1,terms);

%makes the vector: [1 3 5...]
f = terms * 2;
b = (1:2:f);

%for loop to make a vector: containing factorials: [1! 3! 5!...]
for p = 1:terms
    if p == 1
        z(p) = 1;
    else
        l = b(1,p);
        z(p) = factorial(l);  
    end
       
end

%for loop to copy the rows into the 3 matrices
for i = 1:length(x)
    k(i,:) = x(i);
    k(i,2:2:terms) = -k(i,2:2:terms); %makes the sign alternate
    m(i,:) = b;
    factorialmatrix(i,:) = z;
end

%peforms the compution elementwise 
d = (k.^m)./factorialmatrix;

%calculates the answer for each input by summing the corresponding row
for i = 1:length(x)
    taylorseries = d(i,:);
    g(i,:) = sum(taylorseries);   
end