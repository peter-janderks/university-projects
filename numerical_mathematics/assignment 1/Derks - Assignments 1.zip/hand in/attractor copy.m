function f = attractor(lmin,lmax,N)
% produces a picture of the "attractor" for a sequence of values lambda
% Peter-Jan Derks

clf %clears the previous figure

if ~exist('N')
  N=200;
end

stepsize = (lmax - lmin) / N;

x = 0.5; %ratio of existing population to the maximum possible population

lambda = [lmin:stepsize:lmax];

%spilts the lambda vector into three parts, because the most efficient
%calculation for the three parts is different
lambda0to1 = lambda(lambda(lambda <= 1) >= 0);
lambda1to3 = lambda(lambda(lambda <= 3) >= 1);
lambda3to4 = lambda(lambda(lambda <= 4) >= 3);

%single limiting value for lambda1to3 is: (lambda-1)/lambda
first_x= (lambda1to3-1)./lambda1to3;
x = ones(length(lambda3to4), 1);

hold on %neccesarry to plot points in a for loop in the same figure

%no computation needed for lambda0to1
if lmin <= 1
   plot(lambda0to1,0);
end

if lmin <= 3
   plot(lambda1to3,first_x);
end


%
y = first_x(length(first_x));
x = (x*y)';
X = zeros(100,length(lambda3to4));

%split the computation of the limiting value for lambda 3 to 4 into 2 loops
%as it takes a number of compuations/'years' before x has converged to a
%value
for year = 1:80
    x = x.*lambda3to4.*(1-x);
    X(year,:)=x;
end

for year = 80:100
    x = x.*lambda3to4.*(1-x);
    X(year,:)=x;
    plot(lambda3to4,x,'-')
end

title('The Attractor')
xlabel([ num2str(lmin) ' < lambda < ' num2str(lmax)]) 
ylabel('x (population ratio)') 

hold off

end




    

