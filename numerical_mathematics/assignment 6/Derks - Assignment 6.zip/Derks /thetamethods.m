function [T,U] = thetamethods(func,S,u0,th,h)

% THETAMETHODS solves the initial value problem for a system of 
%   differential equations via the ?-method. 

%   [T,U] = THETAMETHODS(FUNC,S,U0,TH,H)
%   The input parameters are, a function-handle FUNC which describes the 
%   right-hand side F(T,U) of the differential equation, a column or row 
%   vector S with requested points in time, a column vector with initial 
%   conditions U0 the parameter ?, and the step size h.
%   
%   The output is, in this order, a column vector of times T, and a matrix 
%   U with in every row the solution at the time corresponding to that row 
%   in T.

% assigning initial values to variables
t1 = S(1) + h;
t2 = S(end);
f=[];
umatrix = [u0];
unew = u0;
t = 0;

% itterating through timespan, with t1 as the second point in time 
for i = t1:h:t2
    uold = unew;
    f = @(t,unew)  unew -  uold - h*((1-th)*func(i-h,uold) + th*func(i,unew));
    ft = @(unew) f(t,unew);
    df = @(unew) numjac(f,0,unew,f(0,unew),eps);
    
    %finds the root of f
    unew = multinewton(ft,df,uold);
    umatrix = [umatrix,unew];
end

if length(S) == 2
    T = (S(1):h:t2)';    
    U = umatrix';
else
    T = S;
    times = [S(1),t1:h:t2];
    
    %calculates the U values for times not in the timespan
    U = spline(times,umatrix,T)';
    T = T';
end
end



