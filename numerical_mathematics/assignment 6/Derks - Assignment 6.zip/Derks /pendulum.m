function [] = pendulum(af,bt,n)

% PENDULUM shows the movement of a forced friction free pendulum
%   Peter-Jan Derks
%
%   [] = PENDULUM(AF,BT,N) describes the movement of a pendulum of which 
%   the pivot is periodically moved up and down by solving the
%   differential equation: x''*(1+AF*sin(BT*t))*sin(x) = 0, where AF ? 0 is 
%   the amplitude of the forcing and BT > 0 the frequency.
%
%   The input parameters are AF, BT and the number of periods N of the 
%   forcing.  
%
%   There is no output, but the function produces a picture of 
%   the time-? map by choosing a number of initial points and plotting the 
%   iterations of those points under the map ?_?.

% second derivate written as a system of equations of first derivatives
g=@(t,x) [x(2);-sin(x(1))*(1+af*sin(bt*t))];
tau = 2*pi/bt;
endtime = n * tau;
timespan = [tau:tau:endtime];

%initial values spread over rectangle
x0s = linspace(-pi,pi,50)';
v0s = linspace(-3,3,50)';
initialpoints = [x0s, v0s];


for i = 1:length(initialpoints)
    initialvalues = initialpoints(i,:);
    
    %improves the accuracy of ode45
    options=odeset('AbsTol',1e-8,'RelTol',1e-8);
    [~,x]=ode45(g,timespan,initialvalues,options);
    
    % keeps x between -pi and pi
    w = wrapToPi(x(:,1));
    
    hold on
    plot(w,x(:,2),'.')
    hold off
end

xlabel('x')
ylabel('v')
end



