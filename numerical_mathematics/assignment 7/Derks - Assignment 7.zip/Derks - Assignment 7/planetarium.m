function [time,z]= planetarium(m,ip,iv,T)
% PLANETARIUM shows the movement of planets.
%   Peter-Jan Derks
%
% [TIME,Z] = PLANETARIUM(M,IP,IV,T) 
% Calculates the orbits of planets in two or three dimensions by using an 
% ODE solver to solve a system of first-order differential equations 
% derived from Newton's laws of gravitation. 
%
% The function accepts 4 input paremeters. M is row vector with the masses 
% of the planets. IP is a matrix IP of  initial positions  with size n x p 
% n being the amount of dimensions and p being the amount of planets. IV is 
% a matrix of  initial  velocities with again size n x p. T should be a 
% value for the length of tim over which the movements should be computed.  

% The function makes a picture of the orbits and returns as output a column 
% vector TIME of points in time and a matrix Z of corresponding positions 
% and velocities of the planets.

time = linspace(0,T,500);

%increases accuracy of ODE-solver
options = odeset('RelTol',1e-10,'AbsTol',1e-10);
[time, z]= ode45(@(time,y) systemofequations(time,y,m,ip),time,...
                                                    [ip(:);iv(:)],options);

N = length(m);
K = size(ip,2);
j = 1;

hold on
if N == 2 %plot for two dimensions
    while j <= 2*K
        l = j + 1;
        plot(z(:,j),z(:,l))
        j = j + 2;
    end
    xlabel('x');
    ylabel('y');
    
else %plot for 3 dimensions
    while j <= 3*K
        l = j + 1;
        k = j + 2;
        plot3(z(:,j),z(:,l),z(:,k))
        j = j + 3;
    end

    % plots two points to rescale the z-axis
    plot3(0,0,1000) 
    plot3(0,0,0)

    xlabel('x');
    ylabel('y');
    zlabel('z');
end
hold off
    
end
             

function [dydt] = systemofequations(t,y,m,P,V)
% Forms a total amount of is 2 * n *p equations . n *p equations for the 
% velocities and n * p equations for the accelerations.

G = 6.672e-11; %gravitational constant
ndim = size(P,1); % number of dimensions
np = length(m); % number of planets
W = ndim * np; 
dydt = zeros(W*2,1); %preallocating size of dydt vector

% velocities of all planets
for i = 1:W
    dydt(i) = y(W+i);
end
    
for p = 1:np % loop through planets
    planets = 1:np;
    otherplanets = planets(planets~=p);
    acc = [ndim,(np-1)]; %preallocating size of acc matrix
    i = 1;
    for pp = otherplanets % loop through other planets
        distance = zeros(1,ndim); %preallocating size of distance vector   
        for n = 1:ndim %loop through dimensions
            Ns = (ndim *(pp-1))+ n ; 
            No = ndim*(p-1) + n ; 
            sign =  (y(Ns)-y(No))/abs(y(Ns)-y(No));
            distance(n) = (sign*abs(y(Ns)-y(No)));
        end
        totaldistance = (distance/norm(distance))';   
        no = (totaldistance.*(m(pp)/(norm(distance).^2)));
        acc(1:ndim,i) = no(1:ndim);
        i = i + 1; %counter for acc
    end
    Totalacc = G* sum(acc,2);
    
    %accelaration eqautions of one planet 
    for i = 1:ndim   
         Totalacc(i);
         dydt(W+(ndim*(p-1)+i)) = Totalacc(i);
    end
    
end
end