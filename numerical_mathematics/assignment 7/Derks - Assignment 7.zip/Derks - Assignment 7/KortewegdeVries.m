function [Time, x, u] = KortewegdeVries(u0, L, T, S, N,plots)
% [TIME,X,U] = KortewegdeVries(U0, L, T, S, N,) shows a moderatly high
% waves in a shallow chanel by solving the Korteweg-de Vries equation by 
% discretizing the spacial variable
%   Peter-Jan Derks
%
% The function accepts 6 input parameters of which two are optional. U0 is 
% the (almost) periodic initial conditions U0 (a function handle). L is 
% half of the length  of  the  interval of the wave as the interval is
% -L < x < L. T is the length  of time. S is the number of  time  steps, S, 
% N is an optional input and determines the number of spatial 
% discretization points. P is an optional input and determines if a 3
% dimensional plot is outputted or a 2 dimensional wave animation.
% 
% The function gives three outputs and can plot either an 2 dimensional 
% wave animationoutput or a 3 dimensional plot. TIME is a vector of points 
% in time. X is a vector of discretization points. U is a  matrix 
% containing the profile of the solution at points in time and space, such 
% that it is easy to plot. 

if ~exist('N')
    N = 100;
end

if ~exist('plots')
    plots = 1;
end

Time = (T/S) * [1:S];
dx = (2*L)/(N-1);
x = [-L:dx:L];

% makes the matrix for the third order derivative 
B = triu(ones(N),1)*-2 +triu(ones(N),2)*3 + triu(ones(N),3)*-1;
A = B - B';
A(1,N) = 2; A(1,N-1) = -1;  % for the BCs, j = 1
A(2,N) = -1;                % for the BCs, j = 2
A(N-1,1) = 1;               % for the BCs, j = N-1
A(N,1) = -2; A(N,2) = 1;    % for the BCs, j = N
B = B/(2*(dx)^3);

% makes the matrix for the first order derivative
C = triu(ones(N),1)-triu(ones(N),2);
D = C - C';                 
D(1,N) = -1;                % for the BCs, j = 1
D(N,1) = 1;                 % for the BCs, j = N
D = D/(2*dx);

IC = zeros(N,1);
X_points = linspace(-L,L,N);
IC = u0(X_points);

f = @(t,u) -(A*u) - ((6 * u)' * (D*u));

options = odeset('RelTol',1e-8,'AbsTol',1e-8);
[Time,u] = ode45(f, Time ,IC, options);

if plots == 1
    for n = 1:length(Time)
        plot(x,u(n,:));
        drawnow;
        pause(.2);
    end 
else 
    surf(Time,x,u'); 
    xlabel('time');
    ylabel('space');
    zlabel('u(t,x)');
end

end

